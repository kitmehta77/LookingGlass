﻿namespace LookingGlass
{
}
namespace LookingGlass
{


    partial class dsLookingGlass
    {
    }
}
